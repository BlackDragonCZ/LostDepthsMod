

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class Workstation2Block extends
Block
implements EntityBlock
{
public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
public Workstation2Block() {
super(
BlockBehaviour.Properties.of(Material.METAL)
.sound(SoundType.METAL)
.strength(6f, 12f)
.noOcclusion()
.isRedstoneConductor((bs, br, bp) -> false)
);
this.registerDefaultState(this.stateDefinition.any()
.setValue(FACING, Direction.NORTH)
);
}
@Override public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
return true;
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 0;
}
@Override public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
return Shapes.empty();
}
@Override public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
return
switch (state.getValue(FACING)) {
default ->
Shapes.or(
box(-13, 0, 2,
31, 12.1, 16)
,
box(-15.1, 15, -0.2,
31.1, 17, 2.2)
)
;
case NORTH ->
Shapes.or(
box(-15, 0, 0,
29, 12.1, 14)
,
box(-15.1, 15, 13.8,
31.1, 17, 16.2)
)
;
case EAST ->
Shapes.or(
box(2, 0, -15,
16, 12.1, 29)
,
box(-0.2, 15, -15.1,
2.2, 17, 31.1)
)
;
case WEST ->
Shapes.or(
box(0, 0, -13,
14, 12.1, 31)
,
box(13.8, 15, -15.1,
16.2, 17, 31.1)
)
;
}
; }
@Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
builder.add(FACING);
}
@Override
public BlockState getStateForPlacement(BlockPlaceContext context) {
return this.defaultBlockState()
.setValue(FACING, context.getHorizontalDirection().getOpposite())
;
}
public BlockState rotate(BlockState state, Rotation rot) {
return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
}
public BlockState mirror(BlockState state, Mirror mirrorIn) {
return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
List<ItemStack> dropsOriginal = super.getDrops(state, builder);
if(!dropsOriginal.isEmpty())
return dropsOriginal;
return Collections.singletonList(new ItemStack(this, 1));
}
@Override public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
super.onPlace(blockstate, world, pos, oldState, moving);
world.scheduleTick(pos, this, 1);
}
@Override public void tick
(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
super.tick(blockstate, world, pos, random);
int x = pos.getX();
int y = pos.getY();
int z = pos.getZ();
Workstation2UpdateTickProcedure.execute(world,x,y,z)
;
world.scheduleTick(pos, this, 1);
}
@Override
public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
super.use(blockstate, world, pos, entity, hand, hit);
if(entity instanceof ServerPlayer player) {
NetworkHooks.openScreen(player, new MenuProvider() {
@Override public Component getDisplayName() {
return Component.literal("Alloy Workbench");
}
@Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
return new WSGUI2Menu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(pos));
}
}, pos);
}
return InteractionResult.SUCCESS;
}
@Override public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
BlockEntity tileEntity = worldIn.getBlockEntity(pos);
return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
}
@Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
return new Workstation2BlockEntity(pos, state);
}
@Override
public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
super.triggerEvent(state, world, pos, eventID, eventParam);
BlockEntity blockEntity = world.getBlockEntity(pos);
return blockEntity == null ? false : blockEntity.triggerEvent(eventID, eventParam);
}
@Override public boolean hasAnalogOutputSignal(BlockState state) {
return true;
}
@Override public int getAnalogOutputSignal(BlockState blockState, Level world, BlockPos pos) {
BlockEntity tileentity = world.getBlockEntity(pos);
if (tileentity instanceof Workstation2BlockEntity be)
return AbstractContainerMenu.getRedstoneSignalFromContainer(be);
else
return 0;
}
}