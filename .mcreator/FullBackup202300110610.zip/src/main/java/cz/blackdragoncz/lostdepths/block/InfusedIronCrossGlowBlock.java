

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class InfusedIronCrossGlowBlock extends
Block
{
public InfusedIronCrossGlowBlock() {
super(
BlockBehaviour.Properties.of(Material.METAL)
.sound(SoundType.METAL)
.strength(6f, 12f)
.lightLevel(s -> 15)
.hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 14;
}
@Override public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
List<ItemStack> dropsOriginal = super.getDrops(state, builder);
if(!dropsOriginal.isEmpty())
return dropsOriginal;
return Collections.singletonList(new ItemStack(this, 1));
}
}