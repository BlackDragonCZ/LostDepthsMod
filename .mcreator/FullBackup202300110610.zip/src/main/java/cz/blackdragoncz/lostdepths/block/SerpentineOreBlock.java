

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class SerpentineOreBlock extends
Block
{
public SerpentineOreBlock() {
super(
BlockBehaviour.Properties.of(Material.STONE)
.sound(SoundType.STONE)
.strength(2f, 12f)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
SerpentineOreBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ(),entity
);
return retval;
}
@Override public void wasExploded(Level world, BlockPos pos, Explosion e) {
super.wasExploded(world, pos, e);
SerpentineOreUnpoweredBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ()
);
}
}