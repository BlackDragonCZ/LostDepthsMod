

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class FerroLeavesBlock extends
Block
{
public FerroLeavesBlock() {
super(
BlockBehaviour.Properties.of(Material.LEAVES)
.sound(SoundType.VINE)
.strength(3f, 12f)
.noOcclusion()
.isRedstoneConductor((bs, br, bp) -> false)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 1;
}
@Override public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
return Shapes.empty();
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
FerroLeavesBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ()
);
return retval;
}
}