

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class InfusedIronBrickStairsBlock extends
StairBlock
{
public InfusedIronBrickStairsBlock() {
super(() -> Blocks.AIR.defaultBlockState(),
BlockBehaviour.Properties.of(Material.METAL)
.sound(SoundType.METAL)
.strength(3f, 12f)
.dynamicShape()
);
}
@Override public float getExplosionResistance() {
return 12f;
}
@Override public boolean isRandomlyTicking(BlockState state) {
return false;
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 0;
}
@Override public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
List<ItemStack> dropsOriginal = super.getDrops(state, builder);
if(!dropsOriginal.isEmpty())
return dropsOriginal;
return Collections.singletonList(new ItemStack(this, 1));
}
}