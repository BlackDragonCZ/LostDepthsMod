

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.world.level.material.Material;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class DruidsFlowerBlock extends FlowerBlock
{
public DruidsFlowerBlock() {
super(MobEffects.DARKNESS, 5000,
BlockBehaviour.Properties.of(Material.PLANT)
.sound(SoundType.GRASS)
.instabreak()
.lightLevel(s -> 3)
.noCollission()
);
}
@Override public int getEffectDuration() {
return 5000;
}
@Override public int getFlammability(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
return 100;
}
@Override public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
return 60;
}
@Override public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
List<ItemStack> dropsOriginal = super.getDrops(state, builder);
if(!dropsOriginal.isEmpty())
return dropsOriginal;
return Collections.singletonList(new ItemStack(this));
}
}