

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class MelworiumOreBlock extends
Block
implements EntityBlock
{
public MelworiumOreBlock() {
super(
BlockBehaviour.Properties.of(Material.STONE)
.sound(SoundType.STONE)
.strength(3f, 12f)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
MelworiumOreBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ(),entity
);
return retval;
}
@Override public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
BlockEntity tileEntity = worldIn.getBlockEntity(pos);
return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
}
@Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
return new MelworiumOreBlockEntity(pos, state);
}
@Override
public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
super.triggerEvent(state, world, pos, eventID, eventParam);
BlockEntity blockEntity = world.getBlockEntity(pos);
return blockEntity == null ? false : blockEntity.triggerEvent(eventID, eventParam);
}
@Override public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean isMoving) {
if (state.getBlock() != newState.getBlock()) {
BlockEntity blockEntity = world.getBlockEntity(pos);
if (blockEntity instanceof MelworiumOreBlockEntity be) {
Containers.dropContents(world, pos, be);
world.updateNeighbourForOutputSignal(pos, this);
}
super.onRemove(state, world, pos, newState, isMoving);
}
}
@Override public boolean hasAnalogOutputSignal(BlockState state) {
return true;
}
@Override public int getAnalogOutputSignal(BlockState blockState, Level world, BlockPos pos) {
BlockEntity tileentity = world.getBlockEntity(pos);
if (tileentity instanceof MelworiumOreBlockEntity be)
return AbstractContainerMenu.getRedstoneSignalFromContainer(be);
else
return 0;
}
}