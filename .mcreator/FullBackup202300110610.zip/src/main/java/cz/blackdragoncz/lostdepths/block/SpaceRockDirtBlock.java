

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class SpaceRockDirtBlock extends
Block
{
public SpaceRockDirtBlock() {
super(
BlockBehaviour.Properties.of(Material.DIRT)
.sound(SoundType.GRAVEL)
.strength(1f, 10f)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
SpaceRockDirtBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ(),entity
);
return retval;
}
}