

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class SerpentineOreUnpoweredBlock extends
Block
{
public SerpentineOreUnpoweredBlock() {
super(
BlockBehaviour.Properties.of(Material.STONE)
.sound(SoundType.STONE)
.strength(2f, 12f)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
SerpentineOreUnpoweredBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ()
);
return retval;
}
@Override public void wasExploded(Level world, BlockPos pos, Explosion e) {
super.wasExploded(world, pos, e);
SerpentineOreUnpoweredBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ()
);
}
@Override
public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
super.use(blockstate, world, pos, entity, hand, hit);
int x = pos.getX();
int y = pos.getY();
int z = pos.getZ();
double hitX = hit.getLocation().x;
double hitY = hit.getLocation().y;
double hitZ = hit.getLocation().z;
Direction direction = hit.getDirection();
SerpentineOreUnpoweredOnBlockRightClickedProcedure.execute(world,x,y,z,entity)
;
return InteractionResult.SUCCESS;
}
}