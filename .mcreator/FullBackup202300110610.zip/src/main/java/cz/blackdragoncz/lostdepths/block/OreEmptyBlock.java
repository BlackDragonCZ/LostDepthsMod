

package cz.blackdragoncz.lostdepths.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;

public class OreEmptyBlock extends
Block
implements EntityBlock
{
public OreEmptyBlock() {
super(
BlockBehaviour.Properties.of(Material.STONE)
.sound(SoundType.STONE)
.strength(24f, 32f)
.noLootTable()
);
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
return BlockPathTypes.BLOCKED;
}
@Override public PushReaction getPistonPushReaction(BlockState state) {
return PushReaction.BLOCK;
}
@Override public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
super.onPlace(blockstate, world, pos, oldState, moving);
world.scheduleTick(pos, this, 20);
}
@Override public void tick
(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
super.tick(blockstate, world, pos, random);
int x = pos.getX();
int y = pos.getY();
int z = pos.getZ();
OreEmptyUpdateTickProcedure.execute(world,x,y,z)
;
world.scheduleTick(pos, this, 20);
}
@Override public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
OreEmptyBlockDestroyedByPlayerProcedure.execute(
world,pos.getX(),pos.getY(),pos.getZ(),entity
);
return retval;
}
@Override
public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
super.use(blockstate, world, pos, entity, hand, hit);
int x = pos.getX();
int y = pos.getY();
int z = pos.getZ();
double hitX = hit.getLocation().x;
double hitY = hit.getLocation().y;
double hitZ = hit.getLocation().z;
Direction direction = hit.getDirection();
OreEmptyOnBlockRightClickedProcedure.execute(world,x,y,z,entity)
;
return InteractionResult.SUCCESS;
}
@Override public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
BlockEntity tileEntity = worldIn.getBlockEntity(pos);
return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
}
@Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
return new OreEmptyBlockEntity(pos, state);
}
@Override
public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
super.triggerEvent(state, world, pos, eventID, eventParam);
BlockEntity blockEntity = world.getBlockEntity(pos);
return blockEntity == null ? false : blockEntity.triggerEvent(eventID, eventParam);
}
}