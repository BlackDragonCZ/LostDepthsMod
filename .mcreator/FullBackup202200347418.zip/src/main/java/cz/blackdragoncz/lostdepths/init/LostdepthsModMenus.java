
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import cz.blackdragoncz.lostdepths.world.inventory.WSGUI1Menu;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, LostdepthsMod.MODID);
	public static final RegistryObject<MenuType<WSGUI1Menu>> WSGUI_1 = REGISTRY.register("wsgui_1", () -> IForgeMenuType.create(WSGUI1Menu::new));
}
