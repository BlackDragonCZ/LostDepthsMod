
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import cz.blackdragoncz.lostdepths.item.TheDestroyerItem;
import cz.blackdragoncz.lostdepths.item.RodOfTransformationItem;
import cz.blackdragoncz.lostdepths.item.PowerChargeItem;
import cz.blackdragoncz.lostdepths.item.MagmaSolutionItem;
import cz.blackdragoncz.lostdepths.item.MagmaCompoundItem;
import cz.blackdragoncz.lostdepths.item.MadrigenSolutionItem;
import cz.blackdragoncz.lostdepths.item.LavaStringItem;
import cz.blackdragoncz.lostdepths.item.IronGolemEssenceItem;
import cz.blackdragoncz.lostdepths.item.InfusedIronItem;
import cz.blackdragoncz.lostdepths.item.InfusedCrystalItem;
import cz.blackdragoncz.lostdepths.item.EnergyzedAlloyItem;
import cz.blackdragoncz.lostdepths.item.CorruptedGemstoneItem;
import cz.blackdragoncz.lostdepths.item.AncientKeyOfForgottenItem;
import cz.blackdragoncz.lostdepths.item.AdviconItem;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LostdepthsMod.MODID);
	public static final RegistryObject<Item> THE_PROTECTOR = REGISTRY.register("the_protector_spawn_egg",
			() -> new ForgeSpawnEggItem(LostdepthsModEntities.THE_PROTECTOR, -1, -16737895,
					new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN)));
	public static final RegistryObject<Item> INFUSED_IRON = REGISTRY.register("infused_iron", () -> new InfusedIronItem());
	public static final RegistryObject<Item> INFUSED_IRON_BRICKS = block(LostdepthsModBlocks.INFUSED_IRON_BRICKS, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> ADVICON = REGISTRY.register("advicon", () -> new AdviconItem());
	public static final RegistryObject<Item> INFUSED_IRON_PILLAR = block(LostdepthsModBlocks.INFUSED_IRON_PILLAR, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON_BRICK_STAIRS = block(LostdepthsModBlocks.INFUSED_IRON_BRICK_STAIRS,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON_BRICK_SLAB = block(LostdepthsModBlocks.INFUSED_IRON_BRICK_SLAB,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> CRYSTALIZER = block(LostdepthsModBlocks.CRYSTALIZER, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> WORKSTATION_1 = block(LostdepthsModBlocks.WORKSTATION_1, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_CRYSTAL = REGISTRY.register("infused_crystal", () -> new InfusedCrystalItem());
	public static final RegistryObject<Item> MAGMA_SOLUTION = REGISTRY.register("magma_solution", () -> new MagmaSolutionItem());
	public static final RegistryObject<Item> MAGMA_COMPOUND = REGISTRY.register("magma_compound", () -> new MagmaCompoundItem());
	public static final RegistryObject<Item> ANCIENT_KEY_OF_FORGOTTEN = REGISTRY.register("ancient_key_of_forgotten",
			() -> new AncientKeyOfForgottenItem());
	public static final RegistryObject<Item> CORRUPTED_GEMSTONE = REGISTRY.register("corrupted_gemstone", () -> new CorruptedGemstoneItem());
	public static final RegistryObject<Item> POWER_CHARGE = REGISTRY.register("power_charge", () -> new PowerChargeItem());
	public static final RegistryObject<Item> ENERGYZED_ALLOY = REGISTRY.register("energyzed_alloy", () -> new EnergyzedAlloyItem());
	public static final RegistryObject<Item> MADRIGEN_SOLUTION = REGISTRY.register("madrigen_solution", () -> new MadrigenSolutionItem());
	public static final RegistryObject<Item> DRUIDS_FLOWER = block(LostdepthsModBlocks.DRUIDS_FLOWER, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> COSMIC_CARPET = block(LostdepthsModBlocks.COSMIC_CARPET, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> LAVA_STRING = REGISTRY.register("lava_string", () -> new LavaStringItem());
	public static final RegistryObject<Item> FACTORY_BLOCK = block(LostdepthsModBlocks.FACTORY_BLOCK, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> O_FACTORY_BLOCK = block(LostdepthsModBlocks.O_FACTORY_BLOCK, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> IRON_GOLEM_ESSENCE = REGISTRY.register("iron_golem_essence", () -> new IronGolemEssenceItem());
	public static final RegistryObject<Item> ROD_OF_TRANSFORMATION = REGISTRY.register("rod_of_transformation", () -> new RodOfTransformationItem());
	public static final RegistryObject<Item> DEVENERGY = block(LostdepthsModBlocks.DEVENERGY, null);
	public static final RegistryObject<Item> THE_DESTROYER = REGISTRY.register("the_destroyer", () -> new TheDestroyerItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
