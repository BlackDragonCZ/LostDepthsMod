
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import cz.blackdragoncz.lostdepths.world.features.plants.DruidsFlowerFeature;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

@Mod.EventBusSubscriber
public class LostdepthsModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, LostdepthsMod.MODID);
	public static final RegistryObject<Feature<?>> DRUIDS_FLOWER = REGISTRY.register("druids_flower", DruidsFlowerFeature::feature);
}
