
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;
import cz.blackdragoncz.lostdepths.init.LostdepthsModItems;

public class TheDestroyerItem extends SwordItem {
	public TheDestroyerItem() {
		super(new Tier() {
			public int getUses() {
				return 1000;
			}

			public float getSpeed() {
				return 4f;
			}

			public float getAttackDamageBonus() {
				return 150f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(LostdepthsModItems.ENERGYZED_ALLOY.get()));
			}
		}, 3, -3f, new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).fireResistant());
	}
}
