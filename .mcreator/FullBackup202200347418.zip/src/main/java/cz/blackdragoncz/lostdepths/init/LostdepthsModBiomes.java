
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.biome.Biome;

import cz.blackdragoncz.lostdepths.world.biome.DruidsValleyBiome;
import cz.blackdragoncz.lostdepths.world.biome.DepthBiome;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModBiomes {
	public static final DeferredRegister<Biome> REGISTRY = DeferredRegister.create(ForgeRegistries.BIOMES, LostdepthsMod.MODID);
	public static final RegistryObject<Biome> DEPTH = REGISTRY.register("depth", DepthBiome::createBiome);
	public static final RegistryObject<Biome> DRUIDS_VALLEY = REGISTRY.register("druids_valley", DruidsValleyBiome::createBiome);
}
