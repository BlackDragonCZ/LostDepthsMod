
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class RodOfTransformationItem extends Item {
	public RodOfTransformationItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(1).fireResistant().rarity(Rarity.COMMON));
	}
}
