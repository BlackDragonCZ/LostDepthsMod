
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class LostdepthsModTabs {
	public static CreativeModeTab TAB_LD_MAIN;

	public static void load() {
		TAB_LD_MAIN = new CreativeModeTab("tabld_main") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(LostdepthsModBlocks.INFUSED_IRON_BRICKS.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
