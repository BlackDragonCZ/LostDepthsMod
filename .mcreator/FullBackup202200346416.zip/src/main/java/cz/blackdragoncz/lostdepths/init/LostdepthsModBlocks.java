
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import cz.blackdragoncz.lostdepths.block.Workstation1Block;
import cz.blackdragoncz.lostdepths.block.OFactoryBlockBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronPillarBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBricksBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBrickStairsBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBrickSlabBlock;
import cz.blackdragoncz.lostdepths.block.FactoryBlockBlock;
import cz.blackdragoncz.lostdepths.block.DruidsFlowerBlock;
import cz.blackdragoncz.lostdepths.block.CrystalizerBlock;
import cz.blackdragoncz.lostdepths.block.CosmicCarpetBlock;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LostdepthsMod.MODID);
	public static final RegistryObject<Block> INFUSED_IRON_BRICKS = REGISTRY.register("infused_iron_bricks", () -> new InfusedIronBricksBlock());
	public static final RegistryObject<Block> INFUSED_IRON_PILLAR = REGISTRY.register("infused_iron_pillar", () -> new InfusedIronPillarBlock());
	public static final RegistryObject<Block> INFUSED_IRON_BRICK_STAIRS = REGISTRY.register("infused_iron_brick_stairs",
			() -> new InfusedIronBrickStairsBlock());
	public static final RegistryObject<Block> INFUSED_IRON_BRICK_SLAB = REGISTRY.register("infused_iron_brick_slab",
			() -> new InfusedIronBrickSlabBlock());
	public static final RegistryObject<Block> CRYSTALIZER = REGISTRY.register("crystalizer", () -> new CrystalizerBlock());
	public static final RegistryObject<Block> WORKSTATION_1 = REGISTRY.register("workstation_1", () -> new Workstation1Block());
	public static final RegistryObject<Block> DRUIDS_FLOWER = REGISTRY.register("druids_flower", () -> new DruidsFlowerBlock());
	public static final RegistryObject<Block> COSMIC_CARPET = REGISTRY.register("cosmic_carpet", () -> new CosmicCarpetBlock());
	public static final RegistryObject<Block> FACTORY_BLOCK = REGISTRY.register("factory_block", () -> new FactoryBlockBlock());
	public static final RegistryObject<Block> O_FACTORY_BLOCK = REGISTRY.register("o_factory_block", () -> new OFactoryBlockBlock());
}
