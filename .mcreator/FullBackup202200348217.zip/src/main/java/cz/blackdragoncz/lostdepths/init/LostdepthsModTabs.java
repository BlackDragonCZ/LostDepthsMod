
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class LostdepthsModTabs {
	public static CreativeModeTab TAB_LD_MAIN;
	public static CreativeModeTab TAB_LD_INGOTS;
	public static CreativeModeTab TAB_LD_TOOLS;
	public static CreativeModeTab TAB_DEV_TAB;

	public static void load() {
		TAB_LD_MAIN = new CreativeModeTab("tabld_main") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(LostdepthsModBlocks.INFUSED_IRON_BRICKS.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_LD_INGOTS = new CreativeModeTab("tabld_ingots") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(LostdepthsModItems.CONDENSED_MORFARITE.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_LD_TOOLS = new CreativeModeTab("tabld_tools") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(LostdepthsModItems.FORGEFIRE_PICKAXE.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_DEV_TAB = new CreativeModeTab("tabdev_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(LostdepthsModBlocks.LASER_GATE.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
