
package cz.blackdragoncz.lostdepths.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import cz.blackdragoncz.lostdepths.entity.MrBoomerEntity;
import cz.blackdragoncz.lostdepths.client.model.Modelmr_boomer;

public class MrBoomerRenderer extends MobRenderer<MrBoomerEntity, Modelmr_boomer<MrBoomerEntity>> {
	public MrBoomerRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelmr_boomer(context.bakeLayer(Modelmr_boomer.LAYER_LOCATION)), 0.3f);
	}

	@Override
	public ResourceLocation getTextureLocation(MrBoomerEntity entity) {
		return new ResourceLocation("lostdepths:textures/entities/mr_boomer.png");
	}
}
