
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import cz.blackdragoncz.lostdepths.block.entity.Workstation2BlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.Workstation1BlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.OreEmptyBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.MorfariteOreBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.MelworiumOreBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.GalacticCompressorBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.FireriteOreBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.DevenergyBlockEntity;
import cz.blackdragoncz.lostdepths.block.entity.CrystalizerBlockEntity;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES,
			LostdepthsMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> FIRERITE_ORE = register("firerite_ore", LostdepthsModBlocks.FIRERITE_ORE,
			FireriteOreBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> MELWORIUM_ORE = register("melworium_ore", LostdepthsModBlocks.MELWORIUM_ORE,
			MelworiumOreBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> MORFARITE_ORE = register("morfarite_ore", LostdepthsModBlocks.MORFARITE_ORE,
			MorfariteOreBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CRYSTALIZER = register("crystalizer", LostdepthsModBlocks.CRYSTALIZER,
			CrystalizerBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WORKSTATION_1 = register("workstation_1", LostdepthsModBlocks.WORKSTATION_1,
			Workstation1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> GALACTIC_COMPRESSOR = register("galactic_compressor",
			LostdepthsModBlocks.GALACTIC_COMPRESSOR, GalacticCompressorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DEVENERGY = register("devenergy", LostdepthsModBlocks.DEVENERGY,
			DevenergyBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ORE_EMPTY = register("ore_empty", LostdepthsModBlocks.ORE_EMPTY, OreEmptyBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WORKSTATION_2 = register("workstation_2", LostdepthsModBlocks.WORKSTATION_2,
			Workstation2BlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block,
			BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
