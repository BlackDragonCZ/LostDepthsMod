
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TitaniumMetalloyItem extends Item {
	public TitaniumMetalloyItem() {
		super(new Item.Properties().tab(null).stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
