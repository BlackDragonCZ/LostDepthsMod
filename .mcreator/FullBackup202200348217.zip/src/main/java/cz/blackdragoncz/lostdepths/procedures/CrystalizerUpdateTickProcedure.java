package cz.blackdragoncz.lostdepths.procedures;

import net.minecraft.world.item.ItemStack;

public class CrystalizerUpdateTickProcedure {
	public static void execute() {
		ItemStack i1 = ItemStack.EMPTY;
		ItemStack i2 = ItemStack.EMPTY;
		ItemStack result = ItemStack.EMPTY;
		double energy = 0;
		double time = 0;
		double maxvalue = 0;
		double craftingtime = 0;
		boolean active = false;
		boolean paused = false;
		boolean consumed = false;
	}
}
