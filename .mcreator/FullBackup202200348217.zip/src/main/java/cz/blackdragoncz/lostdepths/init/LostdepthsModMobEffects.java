
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import cz.blackdragoncz.lostdepths.potion.SecurityBypassMobEffect;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, LostdepthsMod.MODID);
	public static final RegistryObject<MobEffect> SECURITY_BYPASS = REGISTRY.register("security_bypass", () -> new SecurityBypassMobEffect());
}
