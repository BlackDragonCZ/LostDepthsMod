
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, LostdepthsMod.MODID);
	public static final RegistryObject<SoundEvent> METAL1 = REGISTRY.register("metal1",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "metal1")));
	public static final RegistryObject<SoundEvent> METAL2 = REGISTRY.register("metal2",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "metal2")));
	public static final RegistryObject<SoundEvent> METAL_STEP = REGISTRY.register("metal_step",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "metal_step")));
	public static final RegistryObject<SoundEvent> SECURITY_GATE_SOUND_EFFECT = REGISTRY.register("security_gate_sound_effect",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "security_gate_sound_effect")));
	public static final RegistryObject<SoundEvent> SECURITY_GATE_SOUND_ZAP = REGISTRY.register("security_gate_sound_zap",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "security_gate_sound_zap")));
	public static final RegistryObject<SoundEvent> DARK_ACTIVATION_EFFECT = REGISTRY.register("dark_activation_effect",
			() -> new SoundEvent(new ResourceLocation("lostdepths", "dark_activation_effect")));
}
