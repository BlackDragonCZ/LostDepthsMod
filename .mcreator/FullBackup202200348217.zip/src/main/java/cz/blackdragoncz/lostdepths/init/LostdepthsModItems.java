
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import cz.blackdragoncz.lostdepths.item.VenomKnifeItem;
import cz.blackdragoncz.lostdepths.item.UnbreakableChainItem;
import cz.blackdragoncz.lostdepths.item.TitaniumMetalloyScrapItem;
import cz.blackdragoncz.lostdepths.item.TitaniumMetalloyItem;
import cz.blackdragoncz.lostdepths.item.TheDestroyerItem;
import cz.blackdragoncz.lostdepths.item.SuperChargedCoilItem;
import cz.blackdragoncz.lostdepths.item.SecurityPass1Item;
import cz.blackdragoncz.lostdepths.item.RoTItem;
import cz.blackdragoncz.lostdepths.item.RawMorfariteItem;
import cz.blackdragoncz.lostdepths.item.RawMelworiteItem;
import cz.blackdragoncz.lostdepths.item.RawFireriteItem;
import cz.blackdragoncz.lostdepths.item.QuestionIconItem;
import cz.blackdragoncz.lostdepths.item.PowerCoreItem;
import cz.blackdragoncz.lostdepths.item.PowerConnectorAssemblyItem;
import cz.blackdragoncz.lostdepths.item.PowerChargeSolutionsItem;
import cz.blackdragoncz.lostdepths.item.PowerChargeItem;
import cz.blackdragoncz.lostdepths.item.MorfariteIngotItem;
import cz.blackdragoncz.lostdepths.item.MetalBranchItem;
import cz.blackdragoncz.lostdepths.item.MelworiteIngotItem;
import cz.blackdragoncz.lostdepths.item.MagmaSolutionItem;
import cz.blackdragoncz.lostdepths.item.MagmaCompoundItem;
import cz.blackdragoncz.lostdepths.item.MadrigenSolutionItem;
import cz.blackdragoncz.lostdepths.item.LostdepthsmanualItem;
import cz.blackdragoncz.lostdepths.item.LorebookiconItem;
import cz.blackdragoncz.lostdepths.item.LavaStringItem;
import cz.blackdragoncz.lostdepths.item.Keycard5Item;
import cz.blackdragoncz.lostdepths.item.Keycard4Item;
import cz.blackdragoncz.lostdepths.item.Keycard3Item;
import cz.blackdragoncz.lostdepths.item.Keycard2Item;
import cz.blackdragoncz.lostdepths.item.Keycard1Item;
import cz.blackdragoncz.lostdepths.item.IronGolemEssenceItem;
import cz.blackdragoncz.lostdepths.item.IonCrystalItem;
import cz.blackdragoncz.lostdepths.item.InfusedRedstoneItem;
import cz.blackdragoncz.lostdepths.item.InfusedIronItem;
import cz.blackdragoncz.lostdepths.item.InfusedCrystalItem;
import cz.blackdragoncz.lostdepths.item.HeroSwordRedItem;
import cz.blackdragoncz.lostdepths.item.HeroSwordGreenItem;
import cz.blackdragoncz.lostdepths.item.HeroSwordBlueItem;
import cz.blackdragoncz.lostdepths.item.HeadguardItem;
import cz.blackdragoncz.lostdepths.item.ForgefirePickaxeItem;
import cz.blackdragoncz.lostdepths.item.ForgefireAxeItem;
import cz.blackdragoncz.lostdepths.item.FireriteIngotItem;
import cz.blackdragoncz.lostdepths.item.FerroRockItem;
import cz.blackdragoncz.lostdepths.item.EnergyzedAlloyItem;
import cz.blackdragoncz.lostdepths.item.DualPowerAssemblyItem;
import cz.blackdragoncz.lostdepths.item.DevstickItem;
import cz.blackdragoncz.lostdepths.item.DarkFuseDiamondItem;
import cz.blackdragoncz.lostdepths.item.CrystalizedPickaxeItem;
import cz.blackdragoncz.lostdepths.item.CorruptedGemstoneItem;
import cz.blackdragoncz.lostdepths.item.CorrosiveTearItem;
import cz.blackdragoncz.lostdepths.item.CondensedMorfariteItem;
import cz.blackdragoncz.lostdepths.item.CondensedMelworiteItem;
import cz.blackdragoncz.lostdepths.item.CondensedFireriteItem;
import cz.blackdragoncz.lostdepths.item.CondensedCosmeriteItem;
import cz.blackdragoncz.lostdepths.item.CelestialStaffItem;
import cz.blackdragoncz.lostdepths.item.CelestialShieldItem;
import cz.blackdragoncz.lostdepths.item.CelestialShieldBlockingItem;
import cz.blackdragoncz.lostdepths.item.CelestialArmorItem;
import cz.blackdragoncz.lostdepths.item.AncientKeyOfForgottenItem;
import cz.blackdragoncz.lostdepths.item.AdviconItem;
import cz.blackdragoncz.lostdepths.item.AdvancedPowerCoreItem;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LostdepthsMod.MODID);
	public static final RegistryObject<Item> INFUSED_IRON_BRICKS = block(LostdepthsModBlocks.INFUSED_IRON_BRICKS, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON_PILLAR = block(LostdepthsModBlocks.INFUSED_IRON_PILLAR, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON_BRICK_STAIRS = block(LostdepthsModBlocks.INFUSED_IRON_BRICK_STAIRS,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON_BRICK_SLAB = block(LostdepthsModBlocks.INFUSED_IRON_BRICK_SLAB,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> SPACE_ROCK = block(LostdepthsModBlocks.SPACE_ROCK, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> SPACE_ROCK_DIRT = block(LostdepthsModBlocks.SPACE_ROCK_DIRT, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> FERRO_LOG = block(LostdepthsModBlocks.FERRO_LOG, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> FERRO_LEAVES = block(LostdepthsModBlocks.FERRO_LEAVES, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> FIRERITE_ORE = block(LostdepthsModBlocks.FIRERITE_ORE, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> MELWORIUM_ORE = block(LostdepthsModBlocks.MELWORIUM_ORE, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> MORFARITE_ORE = block(LostdepthsModBlocks.MORFARITE_ORE, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> FACTORY_BLOCK = block(LostdepthsModBlocks.FACTORY_BLOCK, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> O_FACTORY_BLOCK = block(LostdepthsModBlocks.O_FACTORY_BLOCK, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> COSMIC_CARPET = block(LostdepthsModBlocks.COSMIC_CARPET, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> CRYSTALIZER = block(LostdepthsModBlocks.CRYSTALIZER, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> WORKSTATION_1 = block(LostdepthsModBlocks.WORKSTATION_1, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> GALACTIC_COMPRESSOR = block(LostdepthsModBlocks.GALACTIC_COMPRESSOR, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_IRON = REGISTRY.register("infused_iron", () -> new InfusedIronItem());
	public static final RegistryObject<Item> INFUSED_CRYSTAL = REGISTRY.register("infused_crystal", () -> new InfusedCrystalItem());
	public static final RegistryObject<Item> MAGMA_SOLUTION = REGISTRY.register("magma_solution", () -> new MagmaSolutionItem());
	public static final RegistryObject<Item> MAGMA_COMPOUND = REGISTRY.register("magma_compound", () -> new MagmaCompoundItem());
	public static final RegistryObject<Item> ANCIENT_KEY_OF_FORGOTTEN = REGISTRY.register("ancient_key_of_forgotten",
			() -> new AncientKeyOfForgottenItem());
	public static final RegistryObject<Item> CORRUPTED_GEMSTONE = REGISTRY.register("corrupted_gemstone", () -> new CorruptedGemstoneItem());
	public static final RegistryObject<Item> POWER_CHARGE = REGISTRY.register("power_charge", () -> new PowerChargeItem());
	public static final RegistryObject<Item> ENERGYZED_ALLOY = REGISTRY.register("energyzed_alloy", () -> new EnergyzedAlloyItem());
	public static final RegistryObject<Item> MADRIGEN_SOLUTION = REGISTRY.register("madrigen_solution", () -> new MadrigenSolutionItem());
	public static final RegistryObject<Item> DRUIDS_FLOWER = block(LostdepthsModBlocks.DRUIDS_FLOWER, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> LAVA_STRING = REGISTRY.register("lava_string", () -> new LavaStringItem());
	public static final RegistryObject<Item> IRON_GOLEM_ESSENCE = REGISTRY.register("iron_golem_essence", () -> new IronGolemEssenceItem());
	public static final RegistryObject<Item> QUANTUM_TRANSPORTER = block(LostdepthsModBlocks.QUANTUM_TRANSPORTER, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> INFUSED_REDSTONE = REGISTRY.register("infused_redstone", () -> new InfusedRedstoneItem());
	public static final RegistryObject<Item> MR_BOOMER = REGISTRY.register("mr_boomer_spawn_egg",
			() -> new ForgeSpawnEggItem(LostdepthsModEntities.MR_BOOMER, -16777216, -65536,
					new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN)));
	public static final RegistryObject<Item> THE_PROTECTOR = REGISTRY.register("the_protector_spawn_egg",
			() -> new ForgeSpawnEggItem(LostdepthsModEntities.THE_PROTECTOR, -1, -16737895,
					new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN)));
	public static final RegistryObject<Item> ION_CRYSTAL = REGISTRY.register("ion_crystal", () -> new IonCrystalItem());
	public static final RegistryObject<Item> POWER_CORE = REGISTRY.register("power_core", () -> new PowerCoreItem());
	public static final RegistryObject<Item> HEADGUARD_HELMET = REGISTRY.register("headguard_helmet", () -> new HeadguardItem.Helmet());
	public static final RegistryObject<Item> UNBREAKABLE_CHAIN = REGISTRY.register("unbreakable_chain", () -> new UnbreakableChainItem());
	public static final RegistryObject<Item> FERRO_ROCK = REGISTRY.register("ferro_rock", () -> new FerroRockItem());
	public static final RegistryObject<Item> METAL_BRANCH = REGISTRY.register("metal_branch", () -> new MetalBranchItem());
	public static final RegistryObject<Item> THE_DESTROYER = REGISTRY.register("the_destroyer", () -> new TheDestroyerItem());
	public static final RegistryObject<Item> FORGEFIRE_PICKAXE = REGISTRY.register("forgefire_pickaxe", () -> new ForgefirePickaxeItem());
	public static final RegistryObject<Item> FORGEFIRE_AXE = REGISTRY.register("forgefire_axe", () -> new ForgefireAxeItem());
	public static final RegistryObject<Item> ROD_OF_TRANSFORMATION = REGISTRY.register("rod_of_transformation", () -> new RoTItem());
	public static final RegistryObject<Item> VENOM_KNIFE = REGISTRY.register("venom_knife", () -> new VenomKnifeItem());
	public static final RegistryObject<Item> RAW_MORFARITE = REGISTRY.register("raw_morfarite", () -> new RawMorfariteItem());
	public static final RegistryObject<Item> RAW_FIRERITE = REGISTRY.register("raw_firerite", () -> new RawFireriteItem());
	public static final RegistryObject<Item> RAW_MELWORITE = REGISTRY.register("raw_melworite", () -> new RawMelworiteItem());
	public static final RegistryObject<Item> MORFARITE_INGOT = REGISTRY.register("morfarite_ingot", () -> new MorfariteIngotItem());
	public static final RegistryObject<Item> FIRERITE_INGOT = REGISTRY.register("firerite_ingot", () -> new FireriteIngotItem());
	public static final RegistryObject<Item> MELWORITE_INGOT = REGISTRY.register("melworite_ingot", () -> new MelworiteIngotItem());
	public static final RegistryObject<Item> CONDENSED_MORFARITE = REGISTRY.register("condensed_morfarite", () -> new CondensedMorfariteItem());
	public static final RegistryObject<Item> CONDENSED_FIRERITE = REGISTRY.register("condensed_firerite", () -> new CondensedFireriteItem());
	public static final RegistryObject<Item> CONDENSED_MELWORITE = REGISTRY.register("condensed_melworite", () -> new CondensedMelworiteItem());
	public static final RegistryObject<Item> ADVICON = REGISTRY.register("advicon", () -> new AdviconItem());
	public static final RegistryObject<Item> DEVENERGY = block(LostdepthsModBlocks.DEVENERGY, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> LOSTDEPTHSMANUAL = REGISTRY.register("lostdepthsmanual", () -> new LostdepthsmanualItem());
	public static final RegistryObject<Item> ORE_EMPTY = block(LostdepthsModBlocks.ORE_EMPTY, null);
	public static final RegistryObject<Item> HERO_SWORD_BLUE = REGISTRY.register("hero_sword_blue", () -> new HeroSwordBlueItem());
	public static final RegistryObject<Item> HERO_SWORD_RED = REGISTRY.register("hero_sword_red", () -> new HeroSwordRedItem());
	public static final RegistryObject<Item> HERO_SWORD_GREEN = REGISTRY.register("hero_sword_green", () -> new HeroSwordGreenItem());
	public static final RegistryObject<Item> DARK_FUSE_DIAMOND = REGISTRY.register("dark_fuse_diamond", () -> new DarkFuseDiamondItem());
	public static final RegistryObject<Item> TITANIUM_METALLOY_SCRAP = REGISTRY.register("titanium_metalloy_scrap",
			() -> new TitaniumMetalloyScrapItem());
	public static final RegistryObject<Item> TITANIUM_METALLOY = REGISTRY.register("titanium_metalloy", () -> new TitaniumMetalloyItem());
	public static final RegistryObject<Item> TITANIUM_LOOT_BOX = block(LostdepthsModBlocks.TITANIUM_LOOT_BOX, null);
	public static final RegistryObject<Item> LOREBOOKICON = REGISTRY.register("lorebookicon", () -> new LorebookiconItem());
	public static final RegistryObject<Item> KEYCARD_1 = REGISTRY.register("keycard_1", () -> new Keycard1Item());
	public static final RegistryObject<Item> KEYCARD_2 = REGISTRY.register("keycard_2", () -> new Keycard2Item());
	public static final RegistryObject<Item> KEYCARD_3 = REGISTRY.register("keycard_3", () -> new Keycard3Item());
	public static final RegistryObject<Item> KEYCARD_4 = REGISTRY.register("keycard_4", () -> new Keycard4Item());
	public static final RegistryObject<Item> KEYCARD_5 = REGISTRY.register("keycard_5", () -> new Keycard5Item());
	public static final RegistryObject<Item> SECURITY_PASS_1 = REGISTRY.register("security_pass_1", () -> new SecurityPass1Item());
	public static final RegistryObject<Item> SECURITY_CLEARANCE_GATE_1 = block(LostdepthsModBlocks.SECURITY_CLEARANCE_GATE_1,
			LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> INFUSEDIRON_PILLAR_CROSS = block(LostdepthsModBlocks.INFUSEDIRON_PILLAR_CROSS,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> LASER_GATE = block(LostdepthsModBlocks.LASER_GATE, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASUREBRICKS = block(LostdepthsModBlocks.TREASUREBRICKS, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASUREPILLAR = block(LostdepthsModBlocks.TREASUREPILLAR, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASURESTAIRS = block(LostdepthsModBlocks.TREASURESTAIRS, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASURESLABS = block(LostdepthsModBlocks.TREASURESLABS, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASURECROSS = block(LostdepthsModBlocks.TREASURECROSS, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> DEVSTICK = REGISTRY.register("devstick", () -> new DevstickItem());
	public static final RegistryObject<Item> LASER_GATE_VERTICAL = block(LostdepthsModBlocks.LASER_GATE_VERTICAL, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> INFUSED_IRON_CROSS_GLOW = block(LostdepthsModBlocks.INFUSED_IRON_CROSS_GLOW,
			LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> NEO_GLASS = block(LostdepthsModBlocks.NEO_GLASS, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> TREASURE_GLASS = block(LostdepthsModBlocks.TREASURE_GLASS, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> TREASURE_CROSS_GLOW = block(LostdepthsModBlocks.TREASURE_CROSS_GLOW, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> QUESTION_ICON = REGISTRY.register("question_icon", () -> new QuestionIconItem());
	public static final RegistryObject<Item> SECURITYCLEARANCEGATETEMPLATE = block(LostdepthsModBlocks.SECURITYCLEARANCEGATETEMPLATE, null);
	public static final RegistryObject<Item> TITANIUM_LOOT_BOX_OPEN = block(LostdepthsModBlocks.TITANIUM_LOOT_BOX_OPEN, null);
	public static final RegistryObject<Item> ENDER_LOOT_BOX = block(LostdepthsModBlocks.ENDER_LOOT_BOX, null);
	public static final RegistryObject<Item> CELESTIAL_ARMOR_CHESTPLATE = REGISTRY.register("celestial_armor_chestplate",
			() -> new CelestialArmorItem.Chestplate());
	public static final RegistryObject<Item> CELESTIAL_ARMOR_LEGGINGS = REGISTRY.register("celestial_armor_leggings",
			() -> new CelestialArmorItem.Leggings());
	public static final RegistryObject<Item> CELESTIAL_ARMOR_BOOTS = REGISTRY.register("celestial_armor_boots", () -> new CelestialArmorItem.Boots());
	public static final RegistryObject<Item> CELESTIAL_STAFF = REGISTRY.register("celestial_staff", () -> new CelestialStaffItem());
	public static final RegistryObject<Item> CELESTIAL_CHEST = block(LostdepthsModBlocks.CELESTIAL_CHEST, LostdepthsModTabs.TAB_DEV_TAB);
	public static final RegistryObject<Item> CELESTIAL_CHEST_OPEN = block(LostdepthsModBlocks.CELESTIAL_CHEST_OPEN, null);
	public static final RegistryObject<Item> CELESTIAL_SHIELD = REGISTRY.register("celestial_shield", () -> new CelestialShieldItem());
	public static final RegistryObject<Item> CELESTIAL_SHIELD_BLOCKING = REGISTRY.register("celestial_shield_blocking",
			() -> new CelestialShieldBlockingItem());
	public static final RegistryObject<Item> CRYSTALIZED_PICKAXE = REGISTRY.register("crystalized_pickaxe", () -> new CrystalizedPickaxeItem());
	public static final RegistryObject<Item> CONDENSED_COSMERITE = REGISTRY.register("condensed_cosmerite", () -> new CondensedCosmeriteItem());
	public static final RegistryObject<Item> WORKSTATION_2 = block(LostdepthsModBlocks.WORKSTATION_2, LostdepthsModTabs.TAB_LD_MAIN);
	public static final RegistryObject<Item> SUPER_CHARGED_COIL = REGISTRY.register("super_charged_coil", () -> new SuperChargedCoilItem());
	public static final RegistryObject<Item> DUAL_POWER_ASSEMBLY = REGISTRY.register("dual_power_assembly", () -> new DualPowerAssemblyItem());
	public static final RegistryObject<Item> POWER_CHARGE_SOLUTIONS = REGISTRY.register("power_charge_solutions",
			() -> new PowerChargeSolutionsItem());
	public static final RegistryObject<Item> POWER_CONNECTOR_ASSEMBLY = REGISTRY.register("power_connector_assembly",
			() -> new PowerConnectorAssemblyItem());
	public static final RegistryObject<Item> ADVANCED_POWER_CORE = REGISTRY.register("advanced_power_core", () -> new AdvancedPowerCoreItem());
	public static final RegistryObject<Item> CORROSIVE_TEAR = REGISTRY.register("corrosive_tear", () -> new CorrosiveTearItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
