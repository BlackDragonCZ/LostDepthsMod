
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import cz.blackdragoncz.lostdepths.block.Workstation2Block;
import cz.blackdragoncz.lostdepths.block.Workstation1Block;
import cz.blackdragoncz.lostdepths.block.TreasurestairsBlock;
import cz.blackdragoncz.lostdepths.block.TreasureslabsBlock;
import cz.blackdragoncz.lostdepths.block.TreasurepillarBlock;
import cz.blackdragoncz.lostdepths.block.TreasurecrossBlock;
import cz.blackdragoncz.lostdepths.block.TreasurebricksBlock;
import cz.blackdragoncz.lostdepths.block.TreasureGlassBlock;
import cz.blackdragoncz.lostdepths.block.TreasureCrossGlowBlock;
import cz.blackdragoncz.lostdepths.block.TitaniumLootBoxOpenBlock;
import cz.blackdragoncz.lostdepths.block.TitaniumLootBoxBlock;
import cz.blackdragoncz.lostdepths.block.SpaceRockDirtBlock;
import cz.blackdragoncz.lostdepths.block.SpaceRockBlock;
import cz.blackdragoncz.lostdepths.block.SecurityclearancegatetemplateBlock;
import cz.blackdragoncz.lostdepths.block.SecurityClearanceGate1Block;
import cz.blackdragoncz.lostdepths.block.QuantumTransporterBlock;
import cz.blackdragoncz.lostdepths.block.OreEmptyBlock;
import cz.blackdragoncz.lostdepths.block.OFactoryBlockBlock;
import cz.blackdragoncz.lostdepths.block.NeoGlassBlock;
import cz.blackdragoncz.lostdepths.block.MorfariteOreBlock;
import cz.blackdragoncz.lostdepths.block.MelworiumOreBlock;
import cz.blackdragoncz.lostdepths.block.LaserGateVerticalBlock;
import cz.blackdragoncz.lostdepths.block.LaserGateBlock;
import cz.blackdragoncz.lostdepths.block.InfusedironPillarCrossBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronPillarBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronCrossGlowBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBricksBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBrickStairsBlock;
import cz.blackdragoncz.lostdepths.block.InfusedIronBrickSlabBlock;
import cz.blackdragoncz.lostdepths.block.GalacticCompressorBlock;
import cz.blackdragoncz.lostdepths.block.FireriteOreBlock;
import cz.blackdragoncz.lostdepths.block.FerroLogBlock;
import cz.blackdragoncz.lostdepths.block.FerroLeavesBlock;
import cz.blackdragoncz.lostdepths.block.FactoryBlockBlock;
import cz.blackdragoncz.lostdepths.block.EnderLootBoxBlock;
import cz.blackdragoncz.lostdepths.block.DruidsFlowerBlock;
import cz.blackdragoncz.lostdepths.block.DevenergyBlock;
import cz.blackdragoncz.lostdepths.block.CrystalizerBlock;
import cz.blackdragoncz.lostdepths.block.CosmicCarpetBlock;
import cz.blackdragoncz.lostdepths.block.CelestialChestOpenBlock;
import cz.blackdragoncz.lostdepths.block.CelestialChestBlock;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

public class LostdepthsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LostdepthsMod.MODID);
	public static final RegistryObject<Block> INFUSED_IRON_BRICKS = REGISTRY.register("infused_iron_bricks", () -> new InfusedIronBricksBlock());
	public static final RegistryObject<Block> INFUSED_IRON_PILLAR = REGISTRY.register("infused_iron_pillar", () -> new InfusedIronPillarBlock());
	public static final RegistryObject<Block> INFUSED_IRON_BRICK_STAIRS = REGISTRY.register("infused_iron_brick_stairs",
			() -> new InfusedIronBrickStairsBlock());
	public static final RegistryObject<Block> INFUSED_IRON_BRICK_SLAB = REGISTRY.register("infused_iron_brick_slab",
			() -> new InfusedIronBrickSlabBlock());
	public static final RegistryObject<Block> SPACE_ROCK = REGISTRY.register("space_rock", () -> new SpaceRockBlock());
	public static final RegistryObject<Block> SPACE_ROCK_DIRT = REGISTRY.register("space_rock_dirt", () -> new SpaceRockDirtBlock());
	public static final RegistryObject<Block> FERRO_LOG = REGISTRY.register("ferro_log", () -> new FerroLogBlock());
	public static final RegistryObject<Block> FERRO_LEAVES = REGISTRY.register("ferro_leaves", () -> new FerroLeavesBlock());
	public static final RegistryObject<Block> FIRERITE_ORE = REGISTRY.register("firerite_ore", () -> new FireriteOreBlock());
	public static final RegistryObject<Block> MELWORIUM_ORE = REGISTRY.register("melworium_ore", () -> new MelworiumOreBlock());
	public static final RegistryObject<Block> MORFARITE_ORE = REGISTRY.register("morfarite_ore", () -> new MorfariteOreBlock());
	public static final RegistryObject<Block> FACTORY_BLOCK = REGISTRY.register("factory_block", () -> new FactoryBlockBlock());
	public static final RegistryObject<Block> O_FACTORY_BLOCK = REGISTRY.register("o_factory_block", () -> new OFactoryBlockBlock());
	public static final RegistryObject<Block> COSMIC_CARPET = REGISTRY.register("cosmic_carpet", () -> new CosmicCarpetBlock());
	public static final RegistryObject<Block> CRYSTALIZER = REGISTRY.register("crystalizer", () -> new CrystalizerBlock());
	public static final RegistryObject<Block> WORKSTATION_1 = REGISTRY.register("workstation_1", () -> new Workstation1Block());
	public static final RegistryObject<Block> GALACTIC_COMPRESSOR = REGISTRY.register("galactic_compressor", () -> new GalacticCompressorBlock());
	public static final RegistryObject<Block> DRUIDS_FLOWER = REGISTRY.register("druids_flower", () -> new DruidsFlowerBlock());
	public static final RegistryObject<Block> QUANTUM_TRANSPORTER = REGISTRY.register("quantum_transporter", () -> new QuantumTransporterBlock());
	public static final RegistryObject<Block> DEVENERGY = REGISTRY.register("devenergy", () -> new DevenergyBlock());
	public static final RegistryObject<Block> ORE_EMPTY = REGISTRY.register("ore_empty", () -> new OreEmptyBlock());
	public static final RegistryObject<Block> TITANIUM_LOOT_BOX = REGISTRY.register("titanium_loot_box", () -> new TitaniumLootBoxBlock());
	public static final RegistryObject<Block> SECURITY_CLEARANCE_GATE_1 = REGISTRY.register("security_clearance_gate_1",
			() -> new SecurityClearanceGate1Block());
	public static final RegistryObject<Block> INFUSEDIRON_PILLAR_CROSS = REGISTRY.register("infusediron_pillar_cross",
			() -> new InfusedironPillarCrossBlock());
	public static final RegistryObject<Block> LASER_GATE = REGISTRY.register("laser_gate", () -> new LaserGateBlock());
	public static final RegistryObject<Block> TREASUREBRICKS = REGISTRY.register("treasurebricks", () -> new TreasurebricksBlock());
	public static final RegistryObject<Block> TREASUREPILLAR = REGISTRY.register("treasurepillar", () -> new TreasurepillarBlock());
	public static final RegistryObject<Block> TREASURESTAIRS = REGISTRY.register("treasurestairs", () -> new TreasurestairsBlock());
	public static final RegistryObject<Block> TREASURESLABS = REGISTRY.register("treasureslabs", () -> new TreasureslabsBlock());
	public static final RegistryObject<Block> TREASURECROSS = REGISTRY.register("treasurecross", () -> new TreasurecrossBlock());
	public static final RegistryObject<Block> LASER_GATE_VERTICAL = REGISTRY.register("laser_gate_vertical", () -> new LaserGateVerticalBlock());
	public static final RegistryObject<Block> INFUSED_IRON_CROSS_GLOW = REGISTRY.register("infused_iron_cross_glow",
			() -> new InfusedIronCrossGlowBlock());
	public static final RegistryObject<Block> NEO_GLASS = REGISTRY.register("neo_glass", () -> new NeoGlassBlock());
	public static final RegistryObject<Block> TREASURE_GLASS = REGISTRY.register("treasure_glass", () -> new TreasureGlassBlock());
	public static final RegistryObject<Block> TREASURE_CROSS_GLOW = REGISTRY.register("treasure_cross_glow", () -> new TreasureCrossGlowBlock());
	public static final RegistryObject<Block> SECURITYCLEARANCEGATETEMPLATE = REGISTRY.register("securityclearancegatetemplate",
			() -> new SecurityclearancegatetemplateBlock());
	public static final RegistryObject<Block> TITANIUM_LOOT_BOX_OPEN = REGISTRY.register("titanium_loot_box_open",
			() -> new TitaniumLootBoxOpenBlock());
	public static final RegistryObject<Block> ENDER_LOOT_BOX = REGISTRY.register("ender_loot_box", () -> new EnderLootBoxBlock());
	public static final RegistryObject<Block> CELESTIAL_CHEST = REGISTRY.register("celestial_chest", () -> new CelestialChestBlock());
	public static final RegistryObject<Block> CELESTIAL_CHEST_OPEN = REGISTRY.register("celestial_chest_open", () -> new CelestialChestOpenBlock());
	public static final RegistryObject<Block> WORKSTATION_2 = REGISTRY.register("workstation_2", () -> new Workstation2Block());
}
