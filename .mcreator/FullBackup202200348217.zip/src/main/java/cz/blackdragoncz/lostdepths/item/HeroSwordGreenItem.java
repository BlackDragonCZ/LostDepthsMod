
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HeroSwordGreenItem extends Item {
	public HeroSwordGreenItem() {
		super(new Item.Properties().tab(null).stacksTo(1).fireResistant().rarity(Rarity.COMMON));
	}
}
