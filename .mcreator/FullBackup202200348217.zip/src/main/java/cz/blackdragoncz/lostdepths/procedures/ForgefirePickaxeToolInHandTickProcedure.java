package cz.blackdragoncz.lostdepths.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Registry;
import net.minecraft.core.BlockPos;

import cz.blackdragoncz.lostdepths.init.LostdepthsModItems;

public class ForgefirePickaxeToolInHandTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean status = false;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == LostdepthsModItems.FORGEFIRE_PICKAXE
				.get()) {
			status = true;
			entity.clearFire();
			if (entity instanceof Player _player) {
				_player.getAbilities().invulnerable = status;
				_player.onUpdateAbilities();
			}
		} else {
			status = false;
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == LostdepthsModItems.FORGEFIRE_PICKAXE
				.get() && (entity.level.dimension()) == (Level.OVERWORLD)
				&& (world.getFluidState(new BlockPos(x, y, z)).createLegacyBlock()).getBlock() == Blocks.LAVA
				&& (world.getFluidState(new BlockPos(x, y + 1, z)).createLegacyBlock()).getBlock() == Blocks.LAVA
				&& (world.getFluidState(new BlockPos(x, y + 2, z)).createLegacyBlock()).getBlock() == Blocks.LAVA) {
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(Component.literal("\u00A74WIP"), (true));
		} else if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
				.getItem() == LostdepthsModItems.FORGEFIRE_PICKAXE.get()
				&& (entity.level.dimension()) == (ResourceKey.create(Registry.DIMENSION_REGISTRY, new ResourceLocation("lostdepths:magic_world")))
				&& (world.getFluidState(new BlockPos(x, y, z)).createLegacyBlock()).getBlock() == Blocks.LAVA
				&& (world.getFluidState(new BlockPos(x, y + 1, z)).createLegacyBlock()).getBlock() == Blocks.LAVA
				&& (world.getFluidState(new BlockPos(x, y + 2, z)).createLegacyBlock()).getBlock() == Blocks.LAVA) {
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(Component.literal("\u00A74WIP"), (true));
		}
	}
}
