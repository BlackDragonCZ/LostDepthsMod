package cz.blackdragoncz.lostdepths.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import cz.blackdragoncz.lostdepths.init.LostdepthsModItems;

public class TheDestroyerLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double currenthp = 0;
		if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == LostdepthsModItems.THE_DESTROYER
				.get()) {
			if (entity.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("minecraft:player")))) {
				currenthp = entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1;
				entity.hurt(DamageSource.GENERIC, (float) (currenthp * 0.6));
			} else if (entity.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("lostdepths:mutated")))) {
				entity.hurt(DamageSource.GENERIC, (float) ((new ItemStack(LostdepthsModItems.THE_DESTROYER.get())).getDamageValue() * 1.2));
			}
		}
	}
}
