
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import cz.blackdragoncz.lostdepths.client.renderer.TheProtectorRenderer;
import cz.blackdragoncz.lostdepths.client.renderer.MrBoomerRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LostdepthsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(LostdepthsModEntities.MR_BOOMER.get(), MrBoomerRenderer::new);
		event.registerEntityRenderer(LostdepthsModEntities.THE_PROTECTOR.get(), TheProtectorRenderer::new);
	}
}
