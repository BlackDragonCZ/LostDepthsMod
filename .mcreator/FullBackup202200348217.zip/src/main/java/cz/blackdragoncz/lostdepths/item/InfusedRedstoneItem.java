
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class InfusedRedstoneItem extends Item {
	public InfusedRedstoneItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("\u00A7cDrop from Mr. Boomer"));
	}
}
