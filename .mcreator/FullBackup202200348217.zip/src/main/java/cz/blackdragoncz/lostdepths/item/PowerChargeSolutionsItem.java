
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class PowerChargeSolutionsItem extends Item {
	public PowerChargeSolutionsItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(64).rarity(Rarity.COMMON));
	}
}
