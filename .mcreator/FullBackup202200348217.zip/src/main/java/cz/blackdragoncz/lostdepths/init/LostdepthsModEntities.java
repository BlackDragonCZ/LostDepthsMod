
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cz.blackdragoncz.lostdepths.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import cz.blackdragoncz.lostdepths.entity.TheProtectorEntity;
import cz.blackdragoncz.lostdepths.entity.MrBoomerEntity;
import cz.blackdragoncz.lostdepths.LostdepthsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LostdepthsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LostdepthsMod.MODID);
	public static final RegistryObject<EntityType<MrBoomerEntity>> MR_BOOMER = register("mr_boomer",
			EntityType.Builder.<MrBoomerEntity>of(MrBoomerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(MrBoomerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<TheProtectorEntity>> THE_PROTECTOR = register("the_protector",
			EntityType.Builder.<TheProtectorEntity>of(TheProtectorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TheProtectorEntity::new).fireImmune().sized(0.8f, 3f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			MrBoomerEntity.init();
			TheProtectorEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(MR_BOOMER.get(), MrBoomerEntity.createAttributes().build());
		event.put(THE_PROTECTOR.get(), TheProtectorEntity.createAttributes().build());
	}
}
