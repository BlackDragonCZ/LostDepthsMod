
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Keycard3Item extends Item {
	public Keycard3Item() {
		super(new Item.Properties().tab(null).stacksTo(1).rarity(Rarity.COMMON));
	}
}
