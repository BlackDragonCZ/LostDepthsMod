
package cz.blackdragoncz.lostdepths.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

import cz.blackdragoncz.lostdepths.init.LostdepthsModItems;

public class TitaniumLootBoxOpenBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public TitaniumLootBoxOpenBlock() {
		super(BlockBehaviour.Properties.of(Material.METAL).sound(SoundType.METAL).strength(30f, 10f).lightLevel(s -> 2).noOcclusion()
				.isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {

		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(-7, 0, 0, 23, 10, 16), box(-8.45, 8.5, 10.25, -4.45, 9.25, 11), box(-8.37, 8.5, 5.04, -4.37, 9.25, 5.79),
					box(-9.09, 8.5, 5.04, -8.34, 9.25, 11.04), box(20.36, 8.5, 5.04, 24.36, 9.25, 5.79), box(20.27, 8.5, 10.25, 24.27, 9.25, 11),
					box(24.25, 8.5, 5, 25, 9.25, 11));
			case NORTH -> Shapes.or(box(-7, 0, 0, 23, 10, 16), box(20.45, 8.5, 5, 24.45, 9.25, 5.75), box(20.37, 8.5, 10.21, 24.37, 9.25, 10.96),
					box(24.34, 8.5, 4.96, 25.09, 9.25, 10.96), box(-8.36, 8.5, 10.21, -4.36, 9.25, 10.96), box(-8.27, 8.5, 5, -4.27, 9.25, 5.75),
					box(-9, 8.5, 5, -8.25, 9.25, 11));
			case EAST -> Shapes.or(box(0, 0, -7, 16, 10, 23), box(10.25, 8.5, 20.45, 11, 9.25, 24.45), box(5.04, 8.5, 20.37, 5.79, 9.25, 24.37),
					box(5.04, 8.5, 24.34, 11.04, 9.25, 25.09), box(5.04, 8.5, -8.36, 5.79, 9.25, -4.36), box(10.25, 8.5, -8.27, 11, 9.25, -4.27),
					box(5, 8.5, -9, 11, 9.25, -8.25));
			case WEST -> Shapes.or(box(0, 0, -7, 16, 10, 23), box(5, 8.5, -8.45, 5.75, 9.25, -4.45), box(10.21, 8.5, -8.37, 10.96, 9.25, -4.37),
					box(4.96, 8.5, -9.09, 10.96, 9.25, -8.34), box(10.21, 8.5, 20.36, 10.96, 9.25, 24.36), box(5, 8.5, 20.27, 5.75, 9.25, 24.27),
					box(5, 8.5, 24.25, 11, 9.25, 25));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(LostdepthsModItems.TITANIUM_METALLOY_SCRAP.get(), 2));
	}
}
