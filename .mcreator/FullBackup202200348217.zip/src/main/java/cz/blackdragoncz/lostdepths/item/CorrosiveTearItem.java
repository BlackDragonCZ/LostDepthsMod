
package cz.blackdragoncz.lostdepths.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CorrosiveTearItem extends Item {
	public CorrosiveTearItem() {
		super(new Item.Properties().tab(null).stacksTo(16).fireResistant().rarity(Rarity.COMMON));
	}
}
