
package cz.blackdragoncz.lostdepths.item;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class AncientKeyOfForgottenItem extends Item {
	public AncientKeyOfForgottenItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(1).fireResistant().rarity(Rarity.COMMON));
	}
}
