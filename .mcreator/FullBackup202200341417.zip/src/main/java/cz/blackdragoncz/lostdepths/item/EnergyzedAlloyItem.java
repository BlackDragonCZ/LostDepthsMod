
package cz.blackdragoncz.lostdepths.item;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class EnergyzedAlloyItem extends Item {
	public EnergyzedAlloyItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(64).rarity(Rarity.COMMON));
	}
}
