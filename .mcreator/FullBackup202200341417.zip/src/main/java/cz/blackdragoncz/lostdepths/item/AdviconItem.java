
package cz.blackdragoncz.lostdepths.item;

public class AdviconItem extends Item {
	public AdviconItem() {
		super(new Item.Properties().tab(null).stacksTo(1).rarity(Rarity.COMMON));
	}
}
