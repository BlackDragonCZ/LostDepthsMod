
package cz.blackdragoncz.lostdepths.client.renderer;

import cz.blackdragoncz.lostdepths.entity.TheProtectorEntity;
import cz.blackdragoncz.lostdepths.client.model.Modelthe_protector;

public class TheProtectorRenderer extends MobRenderer<TheProtectorEntity, Modelthe_protector<TheProtectorEntity>> {
	public TheProtectorRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelthe_protector(context.bakeLayer(Modelthe_protector.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(TheProtectorEntity entity) {
		return new ResourceLocation("lostdepths:textures/entities/the_protector.png");
	}
}
