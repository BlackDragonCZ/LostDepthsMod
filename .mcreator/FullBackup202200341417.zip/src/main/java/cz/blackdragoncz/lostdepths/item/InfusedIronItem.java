
package cz.blackdragoncz.lostdepths.item;

import java.util.List;

import cz.blackdragoncz.lostdepths.init.LostdepthsModTabs;

public class InfusedIronItem extends Item {
	public InfusedIronItem() {
		super(new Item.Properties().tab(LostdepthsModTabs.TAB_LD_MAIN).stacksTo(64).rarity(Rarity.COMMON));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("\u00A7cDrop from The Protector"));
	}
}
